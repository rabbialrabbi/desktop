<?php

use Illuminate\Database\Seeder;

class seatsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('seats')->insert([
            'bus_id' => 1,
            'column' => 'A',
            'row' => '1',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 1,
            'column' => 'B',
            'row' => '1',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 1,
            'column' => 'C',
            'row' => '1',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 1,
            'column' => 'A',
            'row' => '2',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 1,
            'column' => 'B',
            'row' => '2',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 1,
            'column' => 'C',
            'row' => '2',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 1,
            'column' => 'A',
            'row' => '3',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 1,
            'column' => 'B',
            'row' => '3',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 1,
            'column' => 'C',
            'row' => '3',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 1,
            'column' => 'A',
            'row' => '4',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 1,
            'column' => 'B',
            'row' => '4',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 1,
            'column' => 'C',
            'row' => '4',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 1,
            'column' => 'A',
            'row' => '5',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 1,
            'column' => 'B',
            'row' => '5',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 1,
            'column' => 'C',
            'row' => '5',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 1,
            'column' => 'A',
            'row' => '6',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 1,
            'column' => 'B',
            'row' => '6',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 1,
            'column' => 'C',
            'row' => '6',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 1,
            'column' => 'A',
            'row' => '7',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 1,
            'column' => 'B',
            'row' => '7',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 1,
            'column' => 'C',
            'row' => '7',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 1,
            'column' => 'A',
            'row' => '8',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 1,
            'column' => 'B',
            'row' => '8',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 1,
            'column' => 'C',
            'row' => '8',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 1,
            'column' => 'A',
            'row' => '9',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 1,
            'column' => 'B',
            'row' => '9',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 1,
            'column' => 'C',
            'row' => '9',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 1,
            'column' => 'A',
            'row' => '10',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 1,
            'column' => 'B',
            'row' => '10',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 1,
            'column' => 'C',
            'row' => '10',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 2,
            'column' => 'A',
            'row' => '1',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 2,
            'column' => 'B',
            'row' => '1',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 2,
            'column' => 'C',
            'row' => '1',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 2,
            'column' => 'A',
            'row' => '2',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 2,
            'column' => 'B',
            'row' => '2',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 2,
            'column' => 'C',
            'row' => '2',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 2,
            'column' => 'A',
            'row' => '3',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 2,
            'column' => 'B',
            'row' => '3',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 2,
            'column' => 'C',
            'row' => '3',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 2,
            'column' => 'A',
            'row' => '4',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 2,
            'column' => 'B',
            'row' => '4',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 2,
            'column' => 'C',
            'row' => '4',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 2,
            'column' => 'A',
            'row' => '5',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 2,
            'column' => 'B',
            'row' => '5',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 2,
            'column' => 'C',
            'row' => '5',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 2,
            'column' => 'A',
            'row' => '6',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 2,
            'column' => 'B',
            'row' => '6',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 2,
            'column' => 'C',
            'row' => '6',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 2,
            'column' => 'A',
            'row' => '7',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 2,
            'column' => 'B',
            'row' => '7',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 2,
            'column' => 'C',
            'row' => '7',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 2,
            'column' => 'A',
            'row' => '8',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 2,
            'column' => 'B',
            'row' => '8',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 2,
            'column' => 'C',
            'row' => '8',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 2,
            'column' => 'A',
            'row' => '9',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 2,
            'column' => 'B',
            'row' => '9',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 2,
            'column' => 'C',
            'row' => '9',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 2,
            'column' => 'A',
            'row' => '10',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 2,
            'column' => 'B',
            'row' => '10',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 2,
            'column' => 'C',
            'row' => '10',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 3,
            'column' => 'A',
            'row' => '1',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 3,
            'column' => 'B',
            'row' => '1',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 3,
            'column' => 'C',
            'row' => '1',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 3,
            'column' => 'A',
            'row' => '2',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 3,
            'column' => 'B',
            'row' => '2',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 3,
            'column' => 'C',
            'row' => '2',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 3,
            'column' => 'A',
            'row' => '3',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 3,
            'column' => 'B',
            'row' => '3',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 3,
            'column' => 'C',
            'row' => '3',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 3,
            'column' => 'A',
            'row' => '4',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 3,
            'column' => 'B',
            'row' => '4',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 3,
            'column' => 'C',
            'row' => '4',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 3,
            'column' => 'A',
            'row' => '5',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 3,
            'column' => 'B',
            'row' => '5',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 3,
            'column' => 'C',
            'row' => '5',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 3,
            'column' => 'A',
            'row' => '6',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 3,
            'column' => 'B',
            'row' => '6',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 3,
            'column' => 'C',
            'row' => '6',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 3,
            'column' => 'A',
            'row' => '7',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 3,
            'column' => 'B',
            'row' => '7',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 3,
            'column' => 'C',
            'row' => '7',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 3,
            'column' => 'A',
            'row' => '8',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 3,
            'column' => 'B',
            'row' => '8',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 3,
            'column' => 'C',
            'row' => '8',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 3,
            'column' => 'A',
            'row' => '9',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 3,
            'column' => 'B',
            'row' => '9',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 3,
            'column' => 'C',
            'row' => '9',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 3,
            'column' => 'A',
            'row' => '10',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 3,
            'column' => 'B',
            'row' => '10',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 3,
            'column' => 'C',
            'row' => '10',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 4,
            'column' => 'A',
            'row' => '1',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 4,
            'column' => 'B',
            'row' => '1',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 4,
            'column' => 'C',
            'row' => '1',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 4,
            'column' => 'D',
            'row' => '1',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 4,
            'column' => 'A',
            'row' => '2',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 4,
            'column' => 'B',
            'row' => '2',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 4,
            'column' => 'C',
            'row' => '2',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 4,
            'column' => 'D',
            'row' => '2',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 4,
            'column' => 'A',
            'row' => '3',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 4,
            'column' => 'B',
            'row' => '3',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 4,
            'column' => 'C',
            'row' => '3',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 4,
            'column' => 'D',
            'row' => '3',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 4,
            'column' => 'A',
            'row' => '4',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 4,
            'column' => 'B',
            'row' => '4',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 4,
            'column' => 'C',
            'row' => '4',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 4,
            'column' => 'D',
            'row' => '4',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 4,
            'column' => 'A',
            'row' => '5',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 4,
            'column' => 'B',
            'row' => '5',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 4,
            'column' => 'C',
            'row' => '5',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 4,
            'column' => 'D',
            'row' => '5',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 4,
            'column' => 'A',
            'row' => '6',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 4,
            'column' => 'B',
            'row' => '6',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 4,
            'column' => 'C',
            'row' => '6',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 4,
            'column' => 'D',
            'row' => '6',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 4,
            'column' => 'A',
            'row' => '7',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 4,
            'column' => 'B',
            'row' => '7',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 4,
            'column' => 'C',
            'row' => '7',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 4,
            'column' => 'D',
            'row' => '7',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 4,
            'column' => 'A',
            'row' => '8',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 4,
            'column' => 'B',
            'row' => '8',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 4,
            'column' => 'C',
            'row' => '8',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 4,
            'column' => 'D',
            'row' => '8',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 4,
            'column' => 'A',
            'row' => '9',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 4,
            'column' => 'B',
            'row' => '9',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 4,
            'column' => 'C',
            'row' => '9',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 4,
            'column' => 'D',
            'row' => '9',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 4,
            'column' => 'A',
            'row' => '10',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 4,
            'column' => 'B',
            'row' => '10',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 4,
            'column' => 'C',
            'row' => '10',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 4,
            'column' => 'D',
            'row' => '10',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 5,
            'column' => 'A',
            'row' => '1',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 5,
            'column' => 'B',
            'row' => '1',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 5,
            'column' => 'C',
            'row' => '1',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 5,
            'column' => 'D',
            'row' => '1',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 5,
            'column' => 'A',
            'row' => '2',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 5,
            'column' => 'B',
            'row' => '2',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 5,
            'column' => 'C',
            'row' => '2',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 5,
            'column' => 'D',
            'row' => '2',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 5,
            'column' => 'A',
            'row' => '3',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 5,
            'column' => 'B',
            'row' => '3',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 5,
            'column' => 'C',
            'row' => '3',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 5,
            'column' => 'D',
            'row' => '3',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 5,
            'column' => 'A',
            'row' => '4',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 5,
            'column' => 'B',
            'row' => '4',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 5,
            'column' => 'C',
            'row' => '4',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 5,
            'column' => 'D',
            'row' => '4',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 5,
            'column' => 'A',
            'row' => '5',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 5,
            'column' => 'B',
            'row' => '5',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 5,
            'column' => 'C',
            'row' => '5',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 5,
            'column' => 'D',
            'row' => '5',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 5,
            'column' => 'A',
            'row' => '6',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 5,
            'column' => 'B',
            'row' => '6',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 5,
            'column' => 'C',
            'row' => '6',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 5,
            'column' => 'D',
            'row' => '6',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 5,
            'column' => 'A',
            'row' => '7',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 5,
            'column' => 'B',
            'row' => '7',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 5,
            'column' => 'C',
            'row' => '7',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 5,
            'column' => 'D',
            'row' => '7',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 5,
            'column' => 'A',
            'row' => '8',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 5,
            'column' => 'B',
            'row' => '8',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 5,
            'column' => 'C',
            'row' => '8',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 5,
            'column' => 'D',
            'row' => '8',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 5,
            'column' => 'A',
            'row' => '9',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 5,
            'column' => 'B',
            'row' => '9',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 5,
            'column' => 'C',
            'row' => '9',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 5,
            'column' => 'D',
            'row' => '9',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 5,
            'column' => 'A',
            'row' => '10',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 5,
            'column' => 'B',
            'row' => '10',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 5,
            'column' => 'C',
            'row' => '10',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 5,
            'column' => 'D',
            'row' => '10',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 6,
            'column' => 'A',
            'row' => '1',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 6,
            'column' => 'B',
            'row' => '1',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 6,
            'column' => 'C',
            'row' => '1',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 6,
            'column' => 'D',
            'row' => '1',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 6,
            'column' => 'A',
            'row' => '2',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 6,
            'column' => 'B',
            'row' => '2',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 6,
            'column' => 'C',
            'row' => '2',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 6,
            'column' => 'D',
            'row' => '2',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 6,
            'column' => 'A',
            'row' => '3',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 6,
            'column' => 'B',
            'row' => '3',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 6,
            'column' => 'C',
            'row' => '3',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 6,
            'column' => 'D',
            'row' => '3',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 6,
            'column' => 'A',
            'row' => '4',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 6,
            'column' => 'B',
            'row' => '4',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 6,
            'column' => 'C',
            'row' => '4',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 6,
            'column' => 'D',
            'row' => '4',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 6,
            'column' => 'A',
            'row' => '5',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 6,
            'column' => 'B',
            'row' => '5',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 6,
            'column' => 'C',
            'row' => '5',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 6,
            'column' => 'D',
            'row' => '5',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 6,
            'column' => 'A',
            'row' => '6',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 6,
            'column' => 'B',
            'row' => '6',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 6,
            'column' => 'C',
            'row' => '6',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 6,
            'column' => 'D',
            'row' => '6',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 6,
            'column' => 'A',
            'row' => '7',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 6,
            'column' => 'B',
            'row' => '7',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 6,
            'column' => 'C',
            'row' => '7',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 6,
            'column' => 'D',
            'row' => '7',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 6,
            'column' => 'A',
            'row' => '8',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 6,
            'column' => 'B',
            'row' => '8',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 6,
            'column' => 'C',
            'row' => '8',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 6,
            'column' => 'D',
            'row' => '8',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 6,
            'column' => 'A',
            'row' => '9',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 6,
            'column' => 'B',
            'row' => '9',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 6,
            'column' => 'C',
            'row' => '9',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 6,
            'column' => 'D',
            'row' => '9',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 6,
            'column' => 'A',
            'row' => '10',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 6,
            'column' => 'B',
            'row' => '10',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 6,
            'column' => 'C',
            'row' => '10',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 6,
            'column' => 'D',
            'row' => '10',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 7,
            'column' => 'A',
            'row' => '1',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 7,
            'column' => 'B',
            'row' => '1',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 7,
            'column' => 'C',
            'row' => '1',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 7,
            'column' => 'A',
            'row' => '2',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 7,
            'column' => 'B',
            'row' => '2',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 7,
            'column' => 'C',
            'row' => '2',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 7,
            'column' => 'A',
            'row' => '3',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 7,
            'column' => 'B',
            'row' => '3',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 7,
            'column' => 'C',
            'row' => '3',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 7,
            'column' => 'A',
            'row' => '4',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 7,
            'column' => 'B',
            'row' => '4',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 7,
            'column' => 'C',
            'row' => '4',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 7,
            'column' => 'A',
            'row' => '5',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 7,
            'column' => 'B',
            'row' => '5',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 7,
            'column' => 'C',
            'row' => '5',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 7,
            'column' => 'A',
            'row' => '6',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 7,
            'column' => 'B',
            'row' => '6',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 7,
            'column' => 'C',
            'row' => '6',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 7,
            'column' => 'A',
            'row' => '7',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 7,
            'column' => 'B',
            'row' => '7',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 7,
            'column' => 'C',
            'row' => '7',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 7,
            'column' => 'A',
            'row' => '8',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 7,
            'column' => 'B',
            'row' => '8',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 7,
            'column' => 'C',
            'row' => '8',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 7,
            'column' => 'A',
            'row' => '9',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 7,
            'column' => 'B',
            'row' => '9',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 7,
            'column' => 'C',
            'row' => '9',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 7,
            'column' => 'A',
            'row' => '10',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 7,
            'column' => 'B',
            'row' => '10',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 7,
            'column' => 'C',
            'row' => '10',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 8,
            'column' => 'A',
            'row' => '1',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 8,
            'column' => 'B',
            'row' => '1',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 8,
            'column' => 'C',
            'row' => '1',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 8,
            'column' => 'A',
            'row' => '2',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 8,
            'column' => 'B',
            'row' => '2',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 8,
            'column' => 'C',
            'row' => '2',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 8,
            'column' => 'A',
            'row' => '3',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 8,
            'column' => 'B',
            'row' => '3',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 8,
            'column' => 'C',
            'row' => '3',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 8,
            'column' => 'A',
            'row' => '4',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 8,
            'column' => 'B',
            'row' => '4',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 8,
            'column' => 'C',
            'row' => '4',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 8,
            'column' => 'A',
            'row' => '5',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 8,
            'column' => 'B',
            'row' => '5',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 8,
            'column' => 'C',
            'row' => '5',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 8,
            'column' => 'A',
            'row' => '6',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 8,
            'column' => 'B',
            'row' => '6',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 8,
            'column' => 'C',
            'row' => '6',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 8,
            'column' => 'A',
            'row' => '7',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 8,
            'column' => 'B',
            'row' => '7',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 8,
            'column' => 'C',
            'row' => '7',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 8,
            'column' => 'A',
            'row' => '8',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 8,
            'column' => 'B',
            'row' => '8',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 8,
            'column' => 'C',
            'row' => '8',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 8,
            'column' => 'A',
            'row' => '9',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 8,
            'column' => 'B',
            'row' => '9',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 8,
            'column' => 'C',
            'row' => '9',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 8,
            'column' => 'A',
            'row' => '10',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 8,
            'column' => 'B',
            'row' => '10',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 8,
            'column' => 'C',
            'row' => '10',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 9,
            'column' => 'A',
            'row' => '1',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 9,
            'column' => 'B',
            'row' => '1',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 9,
            'column' => 'C',
            'row' => '1',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 9,
            'column' => 'A',
            'row' => '2',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 9,
            'column' => 'B',
            'row' => '2',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 9,
            'column' => 'C',
            'row' => '2',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 9,
            'column' => 'A',
            'row' => '3',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 9,
            'column' => 'B',
            'row' => '3',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 9,
            'column' => 'C',
            'row' => '3',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 9,
            'column' => 'A',
            'row' => '4',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 9,
            'column' => 'B',
            'row' => '4',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 9,
            'column' => 'C',
            'row' => '4',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 9,
            'column' => 'A',
            'row' => '5',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 9,
            'column' => 'B',
            'row' => '5',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 9,
            'column' => 'C',
            'row' => '5',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 9,
            'column' => 'A',
            'row' => '6',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 9,
            'column' => 'B',
            'row' => '6',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 9,
            'column' => 'C',
            'row' => '6',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 9,
            'column' => 'A',
            'row' => '7',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 9,
            'column' => 'B',
            'row' => '7',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 9,
            'column' => 'C',
            'row' => '7',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 9,
            'column' => 'A',
            'row' => '8',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 9,
            'column' => 'B',
            'row' => '8',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 9,
            'column' => 'C',
            'row' => '8',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 9,
            'column' => 'A',
            'row' => '9',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 9,
            'column' => 'B',
            'row' => '9',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 9,
            'column' => 'C',
            'row' => '9',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 9,
            'column' => 'A',
            'row' => '10',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 9,
            'column' => 'B',
            'row' => '10',
        ]);

        DB::table('seats')->insert([
            'bus_id' => 9,
            'column' => 'C',
            'row' => '10',
        ]);
    }
}
