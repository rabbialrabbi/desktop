<?php $__env->startSection('body'); ?>

   <div class="wrapper">
       <div class="post-form">
           <h1>Post Ticket </h1>
           <hr>

           <h3>Please Fill All information to Post Ticket</h3>

           <form action="/post/create" method="post">
               <?php echo csrf_field(); ?>
               <p>Name/Agency: <input type="text" name="agency" ><span class="list-error">  <?php echo e($errors->first('agency')); ?></span></p>
               <p>Route Type:  <select name="route" id="">
                       <option value="air">Air</option>
                       <option value="bus">Bus</option>
                       <option value="train">Train</option>
                   </select><span class="list-error">  <?php echo e($errors->first('route')); ?></span> Date: <input type="date" name="date"><span class="list-error">  <?php echo e($errors->first('date')); ?></span></p>
               <p>From : <input type="text" name="from"><span class="list-error">  <?php echo e($errors->first('from')); ?></span> To : <input type="text" name="to"><span class="list-error">  <?php echo e($errors->first('to')); ?></span></p>
               <p>Price: <input type="text" name="price"><span class="list-error">  <?php echo e($errors->first('agency')); ?></span></p>

               <input type="submit" value="Post">

           </form>
       </div>
   </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\apache\htdocs\Project\htdocs\desktop\resources\views/form/post.blade.php ENDPATH**/ ?>