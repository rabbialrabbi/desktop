<?php $__env->startSection('body'); ?>

    <div class="profile-user_head wrapper">
        <h1>Profile</h1>
        <p>Name: Admin</p>
        <p>level: Admin</p>
    </div>


 <div class="profile-user_body wrapper">
     <h2>User Details</h2>
     <table class="table table-hover">
         <thead>

         <tr>
             <th>Name</th>
             <th>Email</th>
             <th>Join Date</th>
             <th></th>
             <th></th>
         </tr>
         </thead>
         <tbody>
         <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <tr>
             <td><?php echo e($user->name); ?></td>
             <td><?php echo e($user->email); ?></td>
             <td><?php echo e($user->created_at); ?></td>
             <td><a href="/user/<?php echo e($user->id); ?>">Edit</a></td>
             <td><a href="/admin/<?php echo e($user->id); ?>">Delete</a></td>
         </tr>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         </tbody>
     </table>

 </div>


    <div class="profile-user_body wrapper">
        <h2>Ticket Details</h2>
        <table class="table table-hover">
            <thead>
            <tr>
                <th>Agency</th>
                <th>From</th>
                <th>To</th>
                <th>price</th>
                <th>status</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $tickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($ticket->agency); ?></td>
                <td><?php echo e($ticket->from); ?></td>
                <td><?php echo e($ticket->to); ?></td>
                <td><?php echo e($ticket->price); ?></td>
                <td><?php echo e($ticket->status); ?></td>

            </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

    </div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\apache\htdocs\Project\desktop\resources\views/adminProfile.blade.php ENDPATH**/ ?>