<?php $__env->startSection('body'); ?>

    <div class="wrapper">
        <table class="table">
            <thead>
            <tr class="table-head">
                <th scope="col">SN</th>
                <th scope="col">Agency</th>
                <th scope="col">Time</th>
                <th scope="col">Destination</th>
                <th scope="col">Type</th>
                <th scope="col">Fare</th>
                <th scope="col"></th>
            </tr>
            </thead>
            <tbody>
            <?php  $i= 0 ?>
            <?php $__currentLoopData = $buses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

               <?php   $i++  ?>
                <tr>
                    <th scope="row"><?php echo e($i); ?></th>
                    <td><?php echo e($bus->agency()->first()->name); ?></td>
                    <td><?php echo e($bus->departure_time); ?></td>
                    <td><?php echo e($bus->route()->first()->departureCity()->first()->name); ?> to <?php echo e($bus->route()->first()->arrivalCity()->first()->name); ?></td>
                    <td><?php echo e($bus->model); ?> <?php echo e($bus->type); ?></td>
                    <td><?php echo e($bus->fare); ?></td>
                    <td><a href="<?php echo e(route('seat.show', ['bus_id' => $bus->id, 'booking_date'=>$booking_date])); ?>" ><button>Booking</button></a></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
        </table>
    </div>
    <?php $__env->stopSection(); ?>



<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\apache\htdocs\Project\htdocs\desktop\resources\views/busDetails.blade.php ENDPATH**/ ?>