<?php $__env->startSection('body'); ?>
    <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
    <script>
        $( function() {
            $( "#datepicker" ).datepicker({
                minDate:0,
                onSelect : function (dateText, inst) {
                    $("input[name='date']").val(dateText);
                    $('#formId').submit(); // <-- SUBMIT
                }
            });
        } );
    </script>

    <div class="wrapper">


        <table class="table">
            <thead>
            <tr class="bg-secondary">
                <th scope="col">Agency</th>
                <th scope="col">Buses</th>
                <th scope="col">First Trip</th>
                <th scope="col">Last Trip</th>
                <th scope="col"></th>
            </tr>
            </thead>
            <tbody>
                <tr>
                    <th scope="row"><?php echo e($agency->name); ?></th>
                    <td><?php echo e(COUNT($agency->bus()->get())); ?> buses</td>
                    <td>N/A</td>
                    <td>N/A</td>
                    <td>
                        <form id="formId" action="/bookingbus" method="GET">
                            <input type="hidden" name="agencyId" value=<?php echo e($agency->id); ?>>
                            <input type="hidden" name="date" id="" value="Nothing">
                            <input type="button" id="datepicker" value="Select Date">
                        </form>
                    </td>
                </tr>

            </tbody>
        </table>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\apache\htdocs\Project\htdocs\desktop\resources\views/agencyDetailsfromAgency.blade.php ENDPATH**/ ?>