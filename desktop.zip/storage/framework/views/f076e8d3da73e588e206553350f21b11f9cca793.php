<?php $__env->startSection('title','Home'); ?>
<?php $__env->startSection('menu','home'); ?>

<?php $__env->startSection('body'); ?>

    
    <?php if($errors->any()): ?>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="wrapper">
                <div class="alert alert-danger alert-dismissible fade show mt-2" role="alert">
                    <?php echo e($e); ?>

                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    
<?php if(session('errorMessage')): ?>
    <div class="wrapper alert alert-danger alert-dismissible fade show" role="alert">
        <strong>Error: </strong> <?php echo e(session('errorMessage')); ?>

        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>

    <?php endif; ?>


    <div id="searchResult" class="formfield">
        <img src= "<?php echo e(asset('image/flyair.jpg')); ?>" alt="BackGround" height="600px">

        <div class="formfield_box row">
            <div class="col-sm-1 col-md-2 col-lg-2"></div>
            <div class="col-sm-10 col-md-8 col-lg-8">
                <form action="/ticket/search" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="form-home">
                        <div class="form-element">
                            <input class="from" list="from" placeholder="Want to go from" name="city_from" required>
                            <datalist id="from">

                                <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($city->name); ?>"></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </datalist>
                            <span></span>
                        </div>
                        <div class="form-element">
                            <input list="to" placeholder="Want to go To" name="city_to" required>
                            <datalist id="to">

                                <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($city->name); ?>"></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </datalist>
                            <span></span>
                        </div>
                        <div class="form-element">
                            <input list="type" value="Bus" name="type" required>
                            <datalist id="type">
                                <option value="Bus">
                            </datalist>
                            <span></span>
                        </div>
                        <div class="form-element">
                            <input type="date" name="search_date">
                        </div>
                        <div class="form-element">
                            <input type="submit">
                        </div>
                        <div class="clr"></div>
                    </div>
                </form>
            </div>
            <div class="col-sm-1 col-md-2 col-lg-2"></div>

        </div>

    </div>

      
            
            
        
    

    <div class="heading ">
        <h2>Our Valuable Agency</h2>
        <div class="heading-uline"></div>
    </div>
    <div class="regular slider wrapper">
        <?php $__currentLoopData = $agencies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agency): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <div><a href="/agency/<?php echo e($agency->id); ?>"><img src="image/<?php echo e($agency->image_name); ?>" alt="<?php echo e($agency->image_name); ?>" ></a></div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>



    <div class="search-result wrapper">
        <div class="heading ">
            <h2>Top Bus Route </h2>
            <div class="heading-uline"></div>
        </div>
        <div class="row">
            <div class="container">

                <table class="table table-hover top-route">
                    <thead>
                    <tr>
                        <th>From</th>
                        <th>To</th>
                        <th>Distance</th>
                        <th>Price</th>
                        <th></th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $router; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $route): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><i class="fa fa-map-marker" aria-hidden="true"> </i>
                                <?php echo e($route->departureCity()->first()->name); ?></td>
                            <td><i class="fa fa-map-marker" aria-hidden="true"></i>
                                <?php echo e($route->arrivalCity()->first()->name); ?></td>
                            <td><?php echo e($route->est_distance); ?></td>
                            <td><?php echo e($route->est_price); ?></td>
                            <td><a href="/booking/<?php echo e($route->departure_id); ?>/<?php echo e($route->arrival_id); ?>"><button>Book Now</button></a></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>



    <div class="available_city wrapper">
        <div class="heading">
        <h2>Available Route </h2>
        <div class="heading-uline"></div>
        </div>

        <div class="row ">
            <div class="col-4 available_city-col">

                <table>
                    <?php $__currentLoopData = $router; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $route): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <a href=""><td><i class="fa fa-map-marker" aria-hidden="true"></i>
                            <?php echo e($route->departureCity()->first()->name); ?></td>
                        <td> ----------></td>
                        <td><i class="fa fa-map-marker" aria-hidden="true"></i>
                            <?php echo e($route->arrivalCity()->first()->name); ?></td>
                        </a>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>

            </div>
            <div class="col-4"></div>
            <div class="col-4"></div>
        </div>
        </div>





    <script src="https://code.jquery.com/jquery-2.2.0.min.js" type="text/javascript"></script>
    <script type="text/javascript" src="//code.jquery.com/jquery-migrate-1.2.1.min.js"></script>
    <script src="<?php echo e(asset('js/slick.js')); ?>" type="text/javascript" charset="utf-8"></script>
    <script type="text/javascript">
        $(document).on('ready', function() {
            $(".regular").slick({
                autoplay: true,
                autoplaySpeed: 1000,
                arrows:false,
                infinite: true,
                slidesToShow: 6,
                slidesToScroll: 1
            });
        });
    </script>


<?php $__env->stopSection(); ?>




<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\apache\htdocs\Project\htdocs\desktop\resources\views/home.blade.php ENDPATH**/ ?>