<?php $__env->startSection('body'); ?>

    <div class="wrapper jumbotron error-booking bg-info">
        <h2><?php echo e($errorMessage); ?></h2>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\apache\htdocs\Project\htdocs\desktop\resources\views/error/bookingError.blade.php ENDPATH**/ ?>