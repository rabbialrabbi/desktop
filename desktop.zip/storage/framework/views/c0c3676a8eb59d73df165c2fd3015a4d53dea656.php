<?php $__env->startSection('body'); ?>
    <div class="formfield">
        <img src= "<?php echo e(asset('image/flyair.jpg')); ?>" alt="BackGround" height="500px">
        <div class="formfield_box">
            <div class="formfield_input">
                <form action="/ticket/search" method="post">
                    <?php echo csrf_field(); ?>
                <table class="formfield_table">
                    <tr class="formfield_table-header">
                        <td>From</td>
                        <td>To</td>
                        <td>Type</td>
                        <td>Time</td>
                        <td></td>
                    </tr>
                    <tr>
                        <td><select name="from" id="" required>
                                <?php $__currentLoopData = $fromValue; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $from): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value='<?php echo e($from); ?>'><?php echo e($from); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select></td>
                        <td><select name="to" id="" required>
                                <?php $__currentLoopData = $toValue; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $to): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value='<?php echo e($to); ?>'><?php echo e($to); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select></td>
                        <td><select name="route" id="" required>
                                <option value="air">Air</option>
                                <option value="bus">Bus</option>
                                <option value="train">Train</option>
                            </select></td>
                        <td><input type="date" name="date" required></td>
                        <td><input type="submit" value="Search"></td>
                    </tr>
                </table>
                </form>

            </div>

        </div>
    </div>

    <?php if($errors->any()): ?>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="wrapper">
            <div class="alert alert-danger alert-dismissible fade show mt-2" role="alert">
                <?php echo e($e); ?>

                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>

    <div class="list">
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card wrapper list_betweenSpace">
            <h5 class="card-header">
                <div class="row">
                    <div class="col-9">
                    <?php echo e($d->agency); ?>

                </div>
                <div class="col-3">
                    Date: <?php echo e($d->date); ?>

                </div>
                </div>
                </h5>


            <div class="card-body">
                <div class="row">
                    <div class="col-9">
                        <span class="list_component">From: <?php echo e($d->from); ?></span>
                        <span class="list_component">To: <?php echo e($d->to); ?></span>
                        <span class="list_component">Price: $<?php echo e($d->price); ?></span>
                    </div>
                    <div class="col-3 ">
                        <a href="/ticket/<?php echo e($d->id); ?>/confirm" class= "btn btn-primary list_button" >Request</a>
                        <a href="/ticket/<?php echo e($d->id); ?>" class="btn btn-primary list_button">Details</a>
                    </div>
                </div>


            </div>
        </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>


<?php $__env->stopSection(); ?>




<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\apache\htdocs\Project\desktop\resources\views/home.blade.php ENDPATH**/ ?>
