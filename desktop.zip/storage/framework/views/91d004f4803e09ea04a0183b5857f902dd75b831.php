<?php $__env->startSection('body'); ?>



    <div class="container">
        <?php if(session('message')): ?>
            <span style="color:red;"> <?php echo e(session('message')); ?></span>
        <?php endif; ?>
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
            <br><br>
        <h3>Add route</h3>
    <form action="addRoute" method="POST">
        <?php echo csrf_field(); ?>
        <div class="row">
            <div class="col-4">From: </div>
            <div class="col-8">
                <select name="fromCity" id="from">
                    <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($city->id); ?>"><?php echo e($city->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <option value="addCity">Add City</option>

                </select>
            </div>
        </div>
        <div class="row">
            <div class="col-4">To: </div>
            <div class="col-8">
                <select name="toCity" id="to">
                    <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($city->id); ?>"><?php echo e($city->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <option value="addCity">Add City</option>

                </select>
            </div>
        </div>
        <div class="row">
            <div class="col-4">Estimate Distance: </div>
            <div class="col-8">
                <input type="text" name="distance">
            </div>
        </div>
        <div class="row">
            <div class="col-4">Estimate Time: </div>
            <div class="col-8">
                <input type="text" name="time">
            </div>
        </div>
        <div class="row">
            <div class="col-4">Estimate Price: </div>
            <div class="col-8">
                <input type="text" name="price">
            </div>
        </div>
        <div><input type="submit" value="Add Route"></div>
    </form>

            
            <div class="available_city wrapper">
                <div class="heading">
                    <h2>Available Route </h2>
                    <div class="heading-uline"></div>
                </div>

                <div class="row ">
                    <div class="col-4 available_city-col">

                        <table>


                            <?php $__currentLoopData = $routes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $route): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <?php if($route->id <=3): ?>
                                    <p><i class="fa fa-map-marker" aria-hidden="true"></i> <?php echo e($route->departureCity()->first()->name); ?> -----------> <?php echo e($route->arrivalCity()->first()->name); ?></p>
                                    <?php else: ?>
                                    <p><i class="fa fa-map-marker" aria-hidden="true"></i> <?php echo e($route->departureCity()->first()->name); ?> -----------> <?php echo e($route->arrivalCity()->first()->name); ?></p>
                                <?php endif; ?>


                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>

                    </div>
                    <div class="col-4"></div>
                    <div class="col-4"></div>
                </div>
            </div>

    </div>

    <script>
        var pointerFrom = document.getElementById('from');
        pointerFrom.onchange = function () {
            var userOption = this.options[this.selectedIndex];
            if(userOption.value === 'addCity'){
                window.open('/admin/addCity', '_self');
            }
        };
        var pointerTo = document.getElementById('to');
        pointerTo.onchange = function () {
            var userOption = this.options[this.selectedIndex];
            if(userOption.value === 'addCity'){
                window.open('/admin/addCity', '_self');
            }
        }
    </script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\apache\htdocs\Project\htdocs\desktop\resources\views/generator/addRoute.blade.php ENDPATH**/ ?>