<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>" type="text/css">
    <title>Document</title>
</head>
<body>
<div class="up-header wrapper">
    <div class="up-header_left">
        <p>E-ticket</p>
    </div>
    <div class="up-header_right">
        <p>+8801223659050</p>
    </div>
</div>

<div class=" navhead">
    <ul class="wrapper">
        <li> <?php if(auth()->guard()->guest()): ?>
            <li >
                <a href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
            </li>
        <?php else: ?>

            <li>

                <a  href="<?php echo e(route('logout')); ?>"
                   onclick="event.preventDefault();
                   document.getElementById('logout-form').submit();">
                    <?php echo e(__('Logout')); ?></a>
                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                        <?php echo csrf_field(); ?>
                    </form>
            </li>
            <?php if( auth()->user()->email == 'admin@g.com'): ?>
                <li >
                    <a href="/admin"><?php echo e(__('Admin')); ?></a>
                </li>
            <?php else: ?>
                <li >
                    <a href="/user"><?php echo e(__('Profile')); ?></a>
                </li>
                <?php endif; ?>
            <?php endif; ?></li>
        <li><a href="/about">About</a></li>
        <li><a href="/booking/create">Post</a></li>
        <li style="border-left: none;"><a href="/ticket">Home</a></li>
    </ul>
</div>

<?php echo $__env->yieldContent('body'); ?>

<div class="footer">
    <p class="wrapper">CopyRight @ 2019</p>

</div>

</body>
</html>






<?php /**PATH E:\apache\htdocs\Project\desktop\resources\views/layout/layout.blade.php ENDPATH**/ ?>