<?php $__env->startSection('body'); ?>

    <div class="wrapper">
        <div class="row persons">
            <div class="col-2"></div>
            <div class="col-9 booking-details">
                <h2><?php echo e($agencyName); ?></h2>
                <div class="row">
                    <div class="col-2 booking-name">
                        <p>Name :</p>
                    </div>
                    <div class="col-5 booking-input">
                        <input type="text" name="person_name" placeholder="Please Enter Your Name...">
                    </div>

                    <div class="col-2 booking-contact">
                        <p>Contact :</p>
                    </div>
                    <div class="col-3 pl-0 booking-input">
                        <input type="text" name="person_contact" placeholder="Number...">
                    </div>
                </div>
                <div class="row">
                    <div class="col-2">
                        <p>From :</p>
                    </div>
                    <div class="col-5 pl-0">
                        <?php echo e($booking['departure_city']); ?>

                    </div>

                    <div class="col-2">
                        <p>To :</p>
                    </div>
                    <div class="col-3 pl-0">
                        <?php echo e($booking['arrival_city']); ?>

                    </div>
                </div>

                <div class="row">
                    <div class="col-2">
                        <p>Date :</p>
                    </div>
                    <div class="col-2 pl-0">
                        <?php echo e($booking['date']); ?>

                    </div>

                    <div class="col-2">
                        <p>Time :</p>
                    </div>
                    <div class="col-2 pl-0">
                        <?php echo e($bus->departure_time); ?>

                    </div>

                    <div class="col-2">
                        <p>Total :</p>
                    </div>
                    <div class="col-2 pl-0">
                        <span id="total_form"></span>
                    </div>
                </div>
            </div>
        </div>
    </div>

        <div class="row wrapper">
            <div class="col-2"></div>
            <div class="col-4 seat">
                <div class="ctr">

                    <div class="row seat-box">
                        <div class="col-4">
                            <div class="get">Gate</div>
                        </div>
                        <div class="col-4">Engine</div>
                        <div class="col-4"><img src="<?php echo e(asset('image/wheel.png')); ?>" alt="wheel" width="50px"
                                                height="45px">
                        </div>
                    </div>

                    <?php if($bus->seats == 3): ?>
                        <?php $__currentLoopData = $columns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $column): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="row seat-box">
                                <div class="col-3">
                                    <div id="seat_id-<?php echo e($column['A']->id); ?>" class="perseat <?php echo e($column['A']->status); ?>"
                                         onclick=booking('<?php echo e($column["A"]->id); ?>','<?php echo e($column["A"]->name); ?>','<?php echo e($bus->fare); ?>','<?php echo e($column["A"]->status); ?>')><?php echo e($column['A']->name); ?></div>
                                </div>
                                <div class="col-3"></div>
                                <div class="col-3">
                                    <div id="seat_id-<?php echo e($column['B']->id); ?>" class="perseat <?php echo e($column['B']->status); ?>"
                                         onclick=booking('<?php echo e($column["B"]->id); ?>','<?php echo e($column["B"]->name); ?>','<?php echo e($bus->fare); ?>','<?php echo e($column["B"]->status); ?>')><?php echo e($column['B']->name); ?></div>
                                </div>
                                <div class="col-3">
                                    <div id="seat_id-<?php echo e($column['C']->id); ?>" class="perseat <?php echo e($column['C']->status); ?>"
                                         onclick=booking('<?php echo e($column["C"]->id); ?>','<?php echo e($column["C"]->name); ?>','<?php echo e($bus->fare); ?>','<?php echo e($column["C"]->status); ?>')><?php echo e($column['C']->name); ?></div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <?php $__currentLoopData = $columns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $column): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="row seat-box">
                                <div class="col-3">
                                    <div id="seat_id-<?php echo e($column['A']->id); ?>" class="perseat <?php echo e($column['A']->status); ?>"
                                         onclick=booking('<?php echo e($column["A"]->id); ?>','<?php echo e($column["A"]->name); ?>','<?php echo e($bus->fare); ?>','<?php echo e($column["A"]->status); ?>')><?php echo e($column['A']->name); ?></div>
                                </div>
                                <div class="col-3 seat-box_col-2">
                                    <div id="seat_id-<?php echo e($column['B']->id); ?>" class="perseat <?php echo e($column['B']->status); ?>"
                                         onclick=booking('<?php echo e($column["B"]->id); ?>','<?php echo e($column["B"]->name); ?>','<?php echo e($bus->fare); ?>','<?php echo e($column["B"]->status); ?>')><?php echo e($column['B']->name); ?></div>
                                </div>
                                <div class="col-3 seat-box_col-3">
                                    <div id="seat_id-<?php echo e($column['C']->id); ?>" class="perseat <?php echo e($column['C']->status); ?>"
                                         onclick=booking('<?php echo e($column["C"]->id); ?>','<?php echo e($column["C"]->name); ?>','<?php echo e($bus->fare); ?>','<?php echo e($column["C"]->status); ?>')><?php echo e($column['C']->name); ?></div>
                                </div>
                                <div class="col-3">
                                    <div id="seat_id-<?php echo e($column['D']->id); ?>" class="perseat <?php echo e($column['D']->status); ?>"
                                         onclick=booking('<?php echo e($column["D"]->id); ?>','<?php echo e($column["D"]->name); ?>','<?php echo e($bus->fare); ?>','<?php echo e($column["D"]->status); ?>')><?php echo e($column['D']->name); ?></div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <?php endif; ?>
                </div>
                <div class="row pl-4">
                    <sapn class="p-2">NB: Booking Remain</sapn><span id="bookedInf" class="p-2"></span>
                </div>
            </div>

            <div class="col-6">
                <div class="seat-details_account">
                    <h4>Account</h4>
                    <form action="/booking" method="POST">
                        <?php echo csrf_field(); ?>
                        <table class="seat-details_table">
                            <thead>
                            <tr>
                                <th>Name</th>
                                <th></th>
                                <th>Fare</th>
                                <th>Amount</th>
                            </tr>
                            </thead>
                            <tbody id="tbody">
                            <input type="hidden" name="route_id" value="<?php echo e($bus->route_id); ?>">
                            <input type="hidden" name="bus_id" value="<?php echo e($bus->id); ?>">
                            <input type="hidden" name="fare" value="<?php echo e($bus->fare); ?>">
                            <input type="hidden" name="date" value="<?php echo e($booking['date']); ?>">
                            <input type="hidden" name="time" value="<?php echo e($bus->departure_time); ?>">
                            </tbody>
                        </table>


                        <div class="row total_box">
                            <div class="col-3"></div>
                            <div class="col-3"></div>
                            <div class="col-3 text-left">Total</div>
                            <div id="total" class="col-3 text-left">00</div>
                        </div>
                        <div class="row submit_button">
                            <div class="col-1"></div>
                            <div class="col-10">
                                <button type="submit" class="seat-details_table-button">Confirm</button>
                            </div>
                            <div class="col-1"></div>
                        </div>
                    </form>
                </div>
            </div>

        </div>

    <script src="https://code.jquery.com/jquery-2.2.0.min.js" type="text/javascript"></script>

    <script>

        
        

        document.getElementById('bookedInf').innerHTML = '<?php echo e(5-$booking['bookedValue']); ?>';

        let i = 0;

        function booking(seat_id, seat_name, fare, status) {

            let hasClass_booked = $('#seat_id-' + seat_id).hasClass('booked');
            let hasClass_pending = status == 'pending' ? true : false;
            let sesson_value = document.getElementById('bookedInf').innerHTML <= 0? true : false;

            if (!hasClass_booked && !hasClass_pending ) {



                    if(sesson_value){

                        $('#seat_id-' + seat_id).removeClass('pending');
                        let value_confirmation = document.getElementById(seat_name);
                        value_confirmation.remove();

                        let body_element = document.getElementById('tbody');

                        //
                        let body_length = body_element.rows.length;
                        let bookingValue =  5- '<?php echo e(($booking['bookedValue'])); ?>' ;
                        let total_booking_value = bookingValue - body_length;

                        document.getElementById('bookedInf').innerHTML = total_booking_value;
                        let total = 0;
                        for (i = 0; i < body_length; i++) {
                            total = total + parseInt(body_element.rows[i].cells[3].innerHTML);
                        }
                        $('#total').text(total+' Tk');
                        $('#total_form').text(total+' Tk');

                    }else{
                        $('#seat_id-' + seat_id).toggleClass('pending');

                        let value_confirmation = document.getElementById(seat_name);

                        if (!value_confirmation) {
                            $('#tbody').append(`<tr id="` + seat_name + `"><td>` + seat_name + `</td><td>X</td><td>` + fare + `</td><td>` + fare + `</td><td><input  type="hidden" name="seat_` + seat_name + `" value="` + seat_id + `"></td></tr>`);

                            let body_element = document.getElementById('tbody');
                            let body_length = body_element.rows.length;
                            let bookingValue = 5 - '<?php echo e(($booking['bookedValue'])); ?>';
                            let total_booking_value = bookingValue - body_length;

                            document.getElementById('bookedInf').innerHTML = total_booking_value;

                            let total = 0;
                            for (i = 0; i < body_length; i++) {
                                total = total + parseInt(body_element.rows[i].cells[3].innerHTML);
                            }
                            $('#total').text(total + ' Tk');
                            $('#total_form').text(total + ' Tk');
                        } else {
                            //UnSelect for account table
                            value_confirmation.remove();

                            let body_element = document.getElementById('tbody');

                            //
                            let body_length = body_element.rows.length;
                            let bookingValue =  5- '<?php echo e(($booking['bookedValue'])); ?>' ;
                            let total_booking_value = bookingValue - body_length;

                            document.getElementById('bookedInf').innerHTML = total_booking_value;
                            let total = 0;
                            for (i = 0; i < body_length; i++) {
                                total = total + parseInt(body_element.rows[i].cells[3].innerHTML);
                            }
                            $('#total').text(total+' Tk');
                            $('#total_form').text(total+' Tk');

                        }
                    }




                }

        }


    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\apache\htdocs\Project\htdocs\desktop\resources\views/seatDetails.blade.php ENDPATH**/ ?>