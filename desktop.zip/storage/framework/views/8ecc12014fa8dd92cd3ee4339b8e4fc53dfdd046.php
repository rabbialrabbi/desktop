 



<?php $__env->startSection('body'); ?>


    <div class="wrapper">
        <h2>Destination : <?php echo e($destination_from->name); ?> to <?php echo e($destination_to->name); ?> </h2>

        <p><strong><?php echo e($destination_to->name); ?> :</strong>
            <?php echo e($destination_to->description); ?> <a href="<?php echo e($destination_to->link); ?>"> More.. </a></p>

        <h5>Estimate Distance: <?php echo e($route_info->est_distance); ?> Km | Estimate Time : <?php echo e($route_info->est_time); ?> hr | Estimate Price : <?php echo e($route_info->est_price); ?> TK</h5>

        <table class="table">
            <thead>
            <tr class="table-head">
                <th scope="col">Agency</th>
                <th scope="col">Trips</th>
                <th scope="col">First Trip</th>
                <th scope="col">Last Trip</th>
                <th scope="col"></th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $routes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $route): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th scope="row"><?php echo e($route['agency']); ?></th>
                <td><?php echo e($route['trips']); ?> (trips)</td>
                <td><?php echo e($route['first_trip']); ?></td>
                <td><?php echo e($route['last_trip']); ?></td>
                <td>
                    <form id="formId<?php echo e($route['agency_id']); ?>" action="/bookingbus" method="GET">
                        <input type="hidden" name="agency_id" value=<?php echo e($route['agency_id']); ?>>
                        <input type="hidden" name="route_id" value=<?php echo e($route_info->id); ?>>

                        <?php if(!$date): ?>
                            <input type="hidden" name="date" id="" value="Nothing">
                            <input type="button" id="datepicker<?php echo e($route['agency_id']); ?>" onclick="datePicker(<?php echo e($route['agency_id']); ?>)" value="Select Date">
                            <?php else: ?>
                            <input type="hidden" name="date" value=<?php echo e($date); ?>>
                            <input type="submit"  value="Find Bus">
                        <?php endif; ?>

                    </form>
                </td>
            </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
        </table>
    </div>

    
    <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>

    <script>
        <?php $__currentLoopData = $routes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $route): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                $("#datepicker<?php echo e($route['agency_id']); ?>").datepicker({
                    minDate:0,
                    onSelect : function (dateText, inst) {
                        $("input[name='date']").val(dateText);
                        $("#formId<?php echo e($route['agency_id']); ?>").submit(); // <-- SUBMIT
                    }
                });
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\apache\htdocs\Project\htdocs\desktop\resources\views/agencyDetails.blade.php ENDPATH**/ ?>