<?php $__env->startSection('title','About'); ?>
<?php $__env->startSection('menu','about'); ?>

<?php $__env->startSection('body'); ?>

<div class="wrapper">
    <h1>About</h1>
    <hr>

    <p><strong>Thanks for visiting my site.</strong> First of all it is a Development site that is still under development.</p>

        <strong>For test purpose Only Dhaka to Rangpur route is available right now</strong>
    <br><br><br><br>
    <strong>Short Description about developer:</strong>
    <br><br>
    <p>Name: Rabbial Anower</p>
    <p>Mail:rabbialrabbi@gmail.com</p>
    <p>Contact: +8801723659050</p>
    <br>
    <p>Resource: https://github.com/rabbialrabbi/desktop.git</p>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\apache\htdocs\Project\htdocs\desktop\resources\views/about.blade.php ENDPATH**/ ?>