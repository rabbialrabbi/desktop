<template>

</template>

<script>
    export default {
        name: "searchResult"
    }
</script>

<style scoped>

</style>
