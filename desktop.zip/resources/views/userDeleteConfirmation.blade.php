@extends('layout.layout')

@section('body')

    <div class="jumbotron wrapper mt-5">
        <h1>The user has been deleted successfully </h1>

    </div>

@endsection