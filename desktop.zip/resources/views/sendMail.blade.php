@extends('layout.layout')

@section('body')

    <div class="jumbotron wrapper mt-5">
        <h1>Thanks For Mail</h1>
        <p>We received you email. We will replay As soon as possible </p>
    </div>

    @endsection