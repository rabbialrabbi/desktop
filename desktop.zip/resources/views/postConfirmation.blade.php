@extends('layout.layout')

@section('body')

    <div class="jumbotron wrapper mt-5">
        <h1>Thanks For posting New Ticket</h1>
        <p>It will be now available to home page for public </p>
    </div>

@endsection