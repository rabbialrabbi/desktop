@extends('layout.layout')

@section('title','About')
@section('menu','about')

@section('body')

<div class="wrapper">
    <h1>About</h1>
    <hr>

    <p><strong>Thanks for visiting my site.</strong> First of all it is a Development site that is still under development.</p>

        <strong>For test purpose Only Dhaka to Rangpur route is available right now</strong>
    <br><br><br><br>
    <strong>Short Description about developer:</strong>
    <br><br>
    <p>Name: Rabbial Anower</p>
    <p>Mail:rabbialrabbi@gmail.com</p>
    <p>Contact: +8801723659050</p>
    <br>
    <p>Resource: https://github.com/rabbialrabbi/desktop.git</p>

</div>
@endsection
