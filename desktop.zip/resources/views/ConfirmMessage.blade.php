@extends('layout.layout')

@section('body')

    <div class="jumbotron wrapper mt-5">
        <h1>Thanks For Booking</h1>
        <p>We received you Request. We will sent a confirmation mail with in short time </p>
    </div>

    @endsection